package task;

import java.io.IOException;
import java.util.Scanner;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class MyDriver {

	public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException {
		Configuration cfg=new Configuration();
		Scanner sc=new Scanner(System.in);
		try{
		System.out.println("Enter the minimum age");
		int minage=sc.nextInt();
		System.out.println("Enter the maximum age");
		int maxage=sc.nextInt();
		if(maxage<minage){
			System.out.println("Maximum age range limit can't be less than minimum age range limit set by you");
			System.out.println("Enter valid Maximum age limit");
			while(maxage<minage){
				System.out.println("Enter the maximum age");
				maxage=sc.nextInt();
			}
		}
		cfg.setInt("minage", minage);
		cfg.setInt("maxage", maxage);
		
		}catch(Exception e){
			System.out.println("Enter a Valid Age In Number");
			System.exit(0);
		}
		Job job=new Job(cfg,"Total Count of People in range Education Wise");
		job.setNumReduceTasks(1);
		job.setMapperClass(MyMapper.class);
		job.setReducerClass(MyReducer.class);
		job.setJarByClass(MyDriver.class);
		job.setInputFormatClass(MyInputFormat.class);
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(IntWritable.class);
		FileInputFormat.addInputPath(job, new Path(args[0]));
		
		FileOutputFormat.setOutputPath(job, new Path(args[1]));
		FileSystem hdfs = FileSystem.get(cfg);
			
			Path newpath = new Path(args[1]);
			if(hdfs.exists(newpath)){
				hdfs.delete(newpath,true);
			}
        sc.close();
		System.exit(job.waitForCompletion(true)?0:1);
	}

}
