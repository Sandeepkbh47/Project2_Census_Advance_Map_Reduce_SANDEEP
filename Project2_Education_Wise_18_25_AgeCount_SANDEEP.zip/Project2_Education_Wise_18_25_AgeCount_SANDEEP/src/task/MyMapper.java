package task;

import java.io.IOException;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class MyMapper extends Mapper<MyKey,MyValue,Text,IntWritable> {
	   	   
       public void map(MyKey key, MyValue value,Context context) throws IOException, InterruptedException{
    	   Configuration cfg=context.getConfiguration();
    	   int minage=Integer.parseInt(cfg.get("minage"));
    	   int maxage=Integer.parseInt(cfg.get("maxage"));
    	   int age=value.getVal().get();
    	   if (age>=minage & age<=maxage){    		   
    		   context.write(new Text(key.getEdu()), new IntWritable(1));
    	   }
    	   
       }
}
