package task;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.WritableComparable;

@SuppressWarnings("rawtypes")
public class MyKey implements WritableComparable {
	IntWritable age;
    
	public IntWritable getAge() {
		return age;
	}

	public void setAge(IntWritable age) {
		this.age = age;
	}

	@Override
	public void readFields(DataInput arg0) throws IOException {
		age.readFields(arg0);
		
	}

	@Override
	public void write(DataOutput arg0) throws IOException {
		age.write(arg0);
		
	}

	@Override
	public int compareTo(Object o) {
		// TODO Auto-generated method stub
		return 0;
	}
     
}
