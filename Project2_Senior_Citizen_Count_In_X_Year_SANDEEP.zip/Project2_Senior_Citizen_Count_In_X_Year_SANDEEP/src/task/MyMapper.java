package task;

import java.io.IOException;
import java.time.Year;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.mapreduce.Mapper;

public class MyMapper extends Mapper<MyKey,MyValue,IntWritable,NullWritable> {
	   static int count=0;
	   
	   public void cleanup(Context context) throws IOException, InterruptedException{
		   try{
		   context.write(new IntWritable(count), null);
		   }catch(Exception e){}
	   }
	   
       public void map(MyKey key, MyValue value,Context context){
    	   Configuration cfg=context.getConfiguration();
    	   int year=Integer.parseInt(cfg.get("year"));
    	   
    	   int diff=year- Year.now().getValue();
    	   
    	   if (key.getAge().get()+diff>=60){    		   
    		   count+=value.getVal().get();
    	   }
    	   
       }
}
