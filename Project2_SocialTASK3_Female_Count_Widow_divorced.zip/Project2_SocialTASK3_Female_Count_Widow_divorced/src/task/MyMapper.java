package task;

import java.io.IOException;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class MyMapper extends Mapper<MyKey,MyValue,Text,IntWritable> {
	   
       public void map(MyKey key, MyValue value,Context context) throws IOException, InterruptedException{
    	       Configuration cfg=context.getConfiguration();
    	       int minage=Integer.parseInt(cfg.get("minage"));
    	       int maxage=Integer.parseInt(cfg.get("maxage"));
    	       int age=key.getAge().get();
    	       if(age>=minage & age <=maxage){
    	        	
    	       String marital_status=value.getMarital_status().toString();
    	       if(marital_status.equals("Divorced") | marital_status.equals("Widowed"))
    	       context.write(new Text(marital_status), new IntWritable(1));;
    	        }
    	   
       }
}
