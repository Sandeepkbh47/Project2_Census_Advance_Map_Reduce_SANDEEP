package task;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.nio.charset.MalformedInputException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;

public class MyValue implements Writable {
    Text marital_status;
    Text gender;
    
	

	public Text getMarital_status() {
		return marital_status;
	}

	public void setMarital_status(Text marital_status) {
		this.marital_status = marital_status;
	}

	public Text getGender() {
		return gender;
	}

	public void setGender(Text gender) {
		this.gender = gender;
	}

	@Override
	public void readFields(DataInput arg0) throws IOException {
		marital_status.readFields(arg0);
		gender.readFields(arg0);
		
	}

	@Override
	public void write(DataOutput arg0) throws IOException {
		marital_status.write(arg0);
		gender.write(arg0);
		
	}

}
